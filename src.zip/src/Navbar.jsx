import { useState, useEffect } from 'react'; 
import { useNavigate, useLocation } from 'react-router-dom';
import {
  FaUserPlus,
  FaSignInAlt,
  FaSignOutAlt,
  FaShoppingCart,
} from 'react-icons/fa';
import './Navbar.css';

const Navbar = ({ auth = {}, cart = {} }) => {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [isScrolled, setIsScrolled] = useState(false);
  const navigate = useNavigate();
  const location = useLocation();

  // Fallback values using destructuring with defaults
  const {
    user = null,
    logout = () => {}
  } = auth;

  const {
    cartItemCount = 0
  } = cart;

  const username = user?.username || '';

  // Add shadow on scroll
  useEffect(() => {
    const handleScroll = () => setIsScrolled(window.scrollY > 10);
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  // Auto-close mobile menu on route change
  useEffect(() => {
    setIsMobileMenuOpen(false);
  }, [location.pathname]);

  const toggleMobileMenu = () => setIsMobileMenuOpen(!isMobileMenuOpen);
  const handleCartClick = () => navigate('/cart');
  const handleSignup = () => navigate('/signup');
  const handleLogin = () => navigate('/login');
  const handleLogout = () => {
    logout();
    navigate('/');
  };

  return (
    <nav className={`navbar ${isScrolled ? 'scrolled' : ''}`}>
      <div className="logo" onClick={() => navigate('/')}>
        OneStop Disposables
      </div>

      <div className={`nav-links ${isMobileMenuOpen ? 'open' : ''}`}>
        <div className="cart-icon-container" onClick={handleCartClick}>
          <FaShoppingCart className="cart-icon" />
          {cartItemCount > 0 && (
            <span className="cart-badge">{cartItemCount}</span>
          )}
        </div>

        {user ? (
          <div className="user-info">
            <span className="username">
              Welcome{username ? `, ${username}` : ''}!
            </span>
            <button onClick={handleLogout} className="logout-button">
              <FaSignOutAlt /> Logout
            </button>
          </div>
        ) : (
          <div className="auth-buttons">
            <button onClick={handleLogin} className="auth-button login-button">
              <FaSignInAlt /> Login
            </button>
            <button onClick={handleSignup} className="auth-button signup-button">
              <FaUserPlus /> Sign Up
            </button>
          </div>
        )}
      </div>

      <div
        className={`hamburger ${isMobileMenuOpen ? 'active' : ''}`}
        onClick={toggleMobileMenu}
      >
        <span></span>
        <span></span>
        <span></span>
      </div>
    </nav>
  );
};

export default Navbar;
