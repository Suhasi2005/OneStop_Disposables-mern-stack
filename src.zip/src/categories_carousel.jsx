import React from "react";
import { useNavigate } from "react-router-dom";
import Slider from "react-slick";
import "slick-carousel/slick/slick.css";
import "slick-carousel/slick/slick-theme.css";
import "./categories_carousel.css";

const Carousel = () => {
  const navigate = useNavigate();

  const slides = [
    {
    image: "dishes_1_category.webp",
    title: "Disposable Plates",
    subtitle: "Serve with Ease & Style",
    path: "/dish"
  },
  {
    image: "./cups_category.avif",
    title: "Paper & Plastic Cups",
    subtitle: "Perfect for Hot & Cold Beverages",
    path: "/cups"
  },
  {
    image: "./box_category.webp",
    title: "Food Boxes",
    subtitle: "Secure & Eco-Friendly Packaging",
    path: "/boxes"
  },
  {
    image: "./napkins_cutlery_1.jpg",
    title: "Napkins & Tissues",
    subtitle: "Soft. Hygienic. Essential.",
    path: "/napkins"
  },
  {
    image: "./glass_category.jpg",
    title: "Serving Glasses",
    subtitle: "From Shots to Shakes",
    path: "/glasses"
  },
  // {
  //   image: "./containers_category.webp",
  //   title: "Storage Containers",
  //   subtitle: "Freshness that Lasts",
  //   path: "/containers"
  // }
  ];

  const settings = {
    dots: true,
    arrows: true,
    infinite: true,
    speed: 700,
    autoplay: true,
    autoplaySpeed: 4000,
    slidesToShow: 1,
    slidesToScroll: 1,
    pauseOnHover: true,
  };

  const handleSlideClick = (path) => {
    navigate(path);//Khali url banase
  };

  return (
    <div className="carousel-wrapper">
      <Slider {...settings}>
        {slides.map((slide, index) => (
          <div 
            key={index} 
            className="carousel-slide"
            onClick={() => handleSlideClick(slide.path)}
            style={{ cursor: "pointer" }}
            role="button"
            tabIndex={0}
            onKeyDown={(e) => {
              if (e.key === "Enter" || e.key === " ") {
                handleSlideClick(slide.path);
              }
            }}
            // aria-label={`Navigate to ${slide.title}`}
          >
            <img 
              src={slide.image} 
              alt={slide.title} 
              className="carousel-img" 
            />
            <div className="carousel-text">
              <h2>{slide.title}</h2>
              <p>{slide.subtitle}</p>
            </div>
          </div>
        ))}
      </Slider>
    </div>
  );
};

export default Carousel;
