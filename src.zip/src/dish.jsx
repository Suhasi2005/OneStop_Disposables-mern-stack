import React from 'react';
import ProductTemplate from './ProductTemplate';

const Disposables = ({ auth, cart }) => {
  const addToCart = (product, quantity = 1, options = null, username = null) => {
    const enrichedProduct = {
      ...product,
      quantity,
      addedBy: username,
      options,
    };
    cart.dispatch({ type: 'ADD_TO_CART', payload: enrichedProduct });
  };

  
  const productsData = {
    products: [
      {
        id: 1,
        name: '3 Compartment Disposable Plate',
        image: 'dish_3cp.jpg',
        price: 10.99,
        rating: 4.6,
        reviews: 68,
        stock: 150,
        material: 'Bagasse',
        description: 'Eco-friendly 3-section plate ideal for meals with sides.',
        features: ['Microwave safe', 'Leak resistant', 'Biodegradable'],
        colors: ['#FFFFFF'],
        unit: 'pack',
        isNew: true,
      },
      {
        id: 2,
        name: '4 Compartment Disposable Plate',
        image: 'dish_4cp.jpg',
        price: 12.49,
        rating: 4.7,
        reviews: 59,
        stock: 100,
        material: 'Palm Leaf',
        description: 'Sturdy 4-compartment plate for portioned meals and snacks.',
        features: ['Reusable', 'Sustainable', 'Premium finish'],
        colors: ['#F8F8F8'],
        unit: 'pack',
        isBestSeller: true,
      },
      // {
      //   id: 3,
      //   name: '9 Compartment Disposable Plate',
      //   image: 'white_cp.jpg',
      //   price: 14.99,
      //   rating: 4.8,
      //   reviews: 83,
      //   stock: 80,
      //   material: 'Sugarcane Fiber',
      //   description: 'Ideal for buffet-style meals or large servings.',
      //   features: ['Large size', 'Compostable', 'Durable'],
      //   colors: ['#FFFFFF'],
      //   unit: 'pack',
      //   isNew: true,
      //   isBestSeller: true,
      // },
      {
        id: 4,
        name: '7 inch Disposable Plate',
        image: 'dish_7.jpg',
        price: 16.99,
        rating: 4.5,
        reviews: 42,
        stock: 60,
        material: 'PP Plastic (Recyclable)',
        description: 'Versatile tray for school, office or event catering.',
        features: ['Reusable', 'Microwave safe', 'Divided sections'],
        colors: ['#EEEEEE'],
        unit: 'pack',
      },
      {
        id: 5,
        name: '9 inch Disposable Plate',
        image: 'dish_9.jpg',
        price: 17.99,
        rating: 4.6,
        reviews: 55,
        stock: 95,
        material: 'Bagasse',
        description: 'Perfect for full thali-style meals with multiple dishes.',
        features: ['Eco-conscious', 'Grease-resistant', 'Strong build'],
        colors: ['#FAFAFA'],
        unit: 'pack',
      },
      {
        id: 6,
        name: '6 inch Disposable Plate',
        image: 'dish_6.jpg',
        price: 18.99,
        rating: 4.7,
        reviews: 48,
        stock: 70,
        material: 'Palm Leaf',
        description: 'Designed for elaborate servings — weddings, functions.',
        features: ['Natural material', 'Tough structure', 'Reusable'],
        colors: ['#ECECEC'],
        unit: 'pack',
      },
      {
        id: 7,
        name: '10 inch Disposable Plate',
        image: 'dish_10.jpg',
        price: 21.99,
        rating: 4.9,
        reviews: 77,
        stock: 50,
        material: 'Sugarcane Bagasse',
        description: 'Ultimate meal platter with 12 compartments for buffets.',
        features: ['Gigantic layout', 'Eco-friendly', 'Heavy duty'],
        colors: ['#FFFFFF'],
        unit: 'pack',
        isNew: true,
        isBestSeller: true,
      },
    ],
    category: 'dish',
    categoryName: 'dish',
    heroImage: 'dishes_1_category.webp',
    heroTitle: 'Multi-Compartment Plates',
    heroDescription: 'Perfect for full meals, thalis, events, and eco-conscious catering.',
    faqs: [
      {
        question: 'Are these plates microwave and freezer safe?',
        answer: 'Yes! Most are microwave-safe and sturdy enough for light freezer use. Refer to material details.',
      },
      {
        question: 'Are these plates reusable?',
        answer: 'Palm leaf and plastic variants are reusable. Sugarcane and bagasse ones are compostable single-use.',
      },
    ],
    // categories: [
    //   { name: 'Cups & Glasses', image: '/images/cups.jpg', path: '/cups' },
    //   { name: 'Cutlery Sets', image: '/images/cutlery.jpg', path: '/boxes' },
    //   { name: 'Takeaway Boxes', image: '/images/boxes.jpg', path: '/containers' },
    //   { name: 'Napkins', image: '/images/napkins.jpg', path: '/napkins' },
    //   { name: 'Plates & Trays', image: '/images/plates.jpg', path: '/dish' },
    // ],
    theme: 'light',
    showBulkSection: true,
    enableCompare: true,
    enableColorSwatches: true,
  };

  return (
    <ProductTemplate
      {...productsData}
      auth={auth}
      cart={cart}
      addToCart={addToCart}
    />
  );
};

export default Disposables;
