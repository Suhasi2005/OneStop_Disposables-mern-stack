import React from 'react';
import ProductTemplate from './ProductTemplate';

const StrawsAndBags = ({ auth, cart }) => {
  const addToCart = (product, quantity = 1, options = null, username = null) => {
    const enrichedProduct = {
      ...product,
      quantity,
      addedBy: username,
      options,
    };
    cart.dispatch({ type: 'ADD_TO_CART', payload: enrichedProduct });
  };

  const productsData = {
    products: [
      // Straws
      {
        id: 301,
        name: 'Paper Straw (White)',
        image: 'straw_paper_white.jpg',
        price: 2.99,
        rating: 4.4,
        reviews: 28,
        stock: 300,
        material: 'Paper',
        description: 'Eco-friendly white paper straws for cold drinks and juices.',
        features: ['Biodegradable', 'Food grade ink', 'Safe for kids'],
        colors: ['#FFFFFF'],
        unit: 'pack of 50',
        isBestSeller: true,
      },
      {
        id: 302,
        name: 'Colorful Paper Straws',
        image: 'straw_paper_color.jpg',
        price: 3.49,
        rating: 4.6,
        reviews: 35,
        stock: 250,
        material: 'Paper',
        description: 'Multicolor straws perfect for parties, cocktails, and events.',
        features: ['Vibrant designs', 'Plastic-free', 'Durable for short use'],
        colors: ['#FF6347', '#FFD700', '#40E0D0'],
        unit: 'pack of 50',
        isNew: true,
      },
      {
        id: 303,
        name: 'PLA Biodegradable Straw',
        image: 'straw_pla.jpg',
        price: 4.99,
        rating: 4.7,
        reviews: 40,
        stock: 180,
        material: 'PLA Bioplastic',
        description: 'Made from corn starch. Ideal for cafes and eco brands.',
        features: ['Compostable', 'Heat resistant', 'Non-toxic'],
        colors: ['#F8F8F8'],
        unit: 'pack of 50',
      },

      // Bags
      {
        id: 401,
        name: 'Brown Kraft Paper Bag (Small)',
        image: 'bag_kraft_small.jpg',
        price: 5.99,
        rating: 4.5,
        reviews: 33,
        stock: 220,
        material: 'Kraft Paper',
        description: 'Durable paper bag for small items or food delivery.',
        features: ['Recyclable', 'Tear-resistant', 'Sturdy handles'],
        colors: ['#D2B48C'],
        unit: 'pack of 25',
        isBestSeller: true,
      },
      {
        id: 402,
        name: 'White Paper Bag with Handle',
        image: 'bag_white.jpg',
        price: 6.49,
        rating: 4.6,
        reviews: 27,
        stock: 190,
        material: 'White Paper',
        description: 'Clean and classy paper bag ideal for takeaways or retail. ',
        features: ['Eco-friendly', 'Smooth finish', 'Twisted handles'],
        colors: ['#FFFFFF'],
        unit: 'pack of 25',
        isNew: true,
      },
      {
        id: 403,
        name: 'Plastic Carry Bag (Transparent)',
        image: 'bag_transparent.jpg',
        price: 4.99,
        rating: 4.3,
        reviews: 30,
        stock: 250,
        material: 'LDPE',
        description: 'Clear plastic bag for general store or takeaway use.',
        features: ['Reusable', 'Flexible', 'Tear-resistant'],
        colors: ['#FAFAFA'],
        unit: 'pack of 50',
      },
    ],
    category: 'straws_bags',
    categoryName: 'Straws & Bags',
    heroImage: 'https://img.freepik.com/free-photo/top-view-eco-paper-bags-stripes_23-2148848811.jpg',
    heroTitle: 'Straws & Carry Bags',
    heroDescription: 'Sustainable and disposable solutions for sipping, shopping, and delivery needs.',
    faqs: [
      {
        question: 'Are the straws safe for hot drinks?',
        answer: 'Paper straws are for cold drinks. PLA straws are heat-resistant and suitable for warm beverages.',
      },
      {
        question: 'Can I get my logo printed on bags?',
        answer: 'Yes! Bulk customization options are available. Contact us for branded packaging.',
      },
    ],
    categories: [
      { name: 'Cups & Glasses', image: '/images/cups.jpg', path: '/cups' },
      { name: 'Cutlery Sets', image: '/images/cutlery.jpg', path: '/boxes' },
      { name: 'Takeaway Boxes', image: '/images/boxes.jpg', path: '/containers' },
      { name: 'Napkins', image: '/images/napkins.jpg', path: '/napkin' },
      { name: 'Plates & Trays', image: '/images/plates.jpg', path: '/dish' },
    ],
    theme: 'light',
    showBulkSection: true,
    enableCompare: true,
    enableColorSwatches: true,
  };

  return (
    <ProductTemplate
      {...productsData}
      auth={auth}
      cart={cart}
      addToCart={addToCart}
    />
  );
};

export default StrawsAndBags;
