import React from 'react';
import ProductTemplate from './ProductTemplate';

const NapkinsAndCutlery = ({ auth, cart }) => {
  const addToCart = (product, quantity = 1, options = null, username = null) => {
    const enrichedProduct = {
      ...product,
      quantity,
      addedBy: username,
      options,
    };
    cart.dispatch({ type: 'ADD_TO_CART', payload: enrichedProduct });
  };

  const productsData = {
    products: [
      // Napkins
      {
        id: 101,
        name: '2-Ply White Paper Napkin',
        image: 'napkin_pill.jpg',
        price: 3.99,
        rating: 4.5,
        reviews: 33,
        stock: 200,
        material: 'Paper',
        description: 'Soft and absorbent 2-ply napkin for general use.',
        features: ['Biodegradable', 'Soft Texture', 'Disposable'],
        colors: ['#FFFFFF'],
        unit: 'pack of 100',
        isBestSeller: true,
      },
      {
        id: 102,
        name: 'Cocktail Napkins (Printed)',
        image: 'cocktail_napkins.jpg',
        price: 5.49,
        rating: 4.7,
        reviews: 20,
        stock: 150,
        material: 'Paper',
        description: 'Stylish printed napkins for parties and events.',
        features: ['Colorful', 'Elegant Design', 'One-time use'],
        colors: ['#F0F0F0'],
        unit: 'pack of 50',
        isNew: true,
      },
      // {
      //   id: 103,
      //   name: 'Dinner Napkin (Folded)',
      //   image: 'napkin_dinner.jpg',
      //   price: 6.99,
      //   rating: 4.6,
      //   reviews: 27,
      //   stock: 90,
      //   material: 'Thick Paper',
      //   description: 'Premium quality folded napkins for formal dinners.',
      //   features: ['Extra large', 'Cloth-like texture', 'Premium feel'],
      //   colors: ['#FFFFFF'],
      //   unit: 'pack of 40',
      // },

      // Cutlery
      {
        id: 201,
        name: 'Wooden Cutlery Set (Spoon, Fork, Knife)',
        image: 'cutlery_wooden.jpg',
        price: 7.99,
        rating: 4.8,
        reviews: 45,
        stock: 120,
        material: 'Wood',
        description: 'Eco-friendly disposable cutlery set made from birchwood.',
        features: ['Plastic-free', 'Durable', 'Compostable'],
        colors: ['#DEB887'],
        unit: 'set of 50',
        isBestSeller: true,
      },
      {
        id: 202,
        name: 'White Plastic Cutlery Set',
        image: 'cutlery_white.avif',
        price: 5.49,
        rating: 4.3,
        reviews: 39,
        stock: 180,
        material: 'PP Plastic',
        description: 'Economical plastic cutlery ideal for bulk catering.',
        features: ['Reusable', 'Lightweight', 'Cost-effective'],
        colors: ['#FFFFFF'],
        unit: 'set of 100',
      },
      {
        id: 203,
        name: 'Black Premium Plastic Cutlery',
        image: 'cutlery_black.jpg',
        price: 6.99,
        rating: 4.6,
        reviews: 31,
        stock: 130,
        material: 'Reinforced Plastic',
        description: 'Elegant black cutlery for premium food service events.',
        features: ['Stylish', 'Sturdy', 'Reusable'],
        colors: ['#000000'],
        unit: 'set of 50',
        isNew: true,
      },
    ],
    category: 'napkin_cutlery',
    categoryName: 'Napkins & Cutlery',
    heroImage: 'https://img.freepik.com/free-photo/top-view-eco-friendly-utensils-paper-napkin_23-2148870466.jpg',
    heroTitle: 'Napkins & Cutlery',
    heroDescription: 'Premium disposable napkins and eco-conscious cutlery for events, catering, and everyday use.',
    faqs: [
      {
        question: 'Are these cutlery sets biodegradable?',
        answer: 'Wooden cutlery sets are biodegradable. Plastic sets are reusable but not compostable.',
      },
      {
        question: 'Can napkins be used for formal dining?',
        answer: 'Yes, the dinner napkins are designed for formal events with premium quality and texture.',
      },
    ],
    categories: [
      { name: 'Cups & Glasses', image: '/images/cups.jpg', path: '/cups' },
      { name: 'Cutlery Sets', image: '/images/cutlery.jpg', path: '/boxes' },
      { name: 'Takeaway Boxes', image: '/images/boxes.jpg', path: '/containers' },
      { name: 'Napkins', image: '/images/napkins.jpg', path: '/napkin' },
      { name: 'Plates & Trays', image: '/images/plates.jpg', path: '/dish' },
    ],
    theme: 'light',
    showBulkSection: true,
    enableCompare: true,
    enableColorSwatches: true,
  };

  return (
    <ProductTemplate
      {...productsData}
      auth={auth}
      cart={cart}
      addToCart={addToCart}
    />
  );
};

export default NapkinsAndCutlery;
