const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const cors = require('cors');

const app = express();

// Middleware
app.use(cors());
app.use(bodyParser.json());

// MongoDB Connection
mongoose.connect('mongodb://127.0.0.1:27017/oneStop_Disposables', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
})
.then(() => console.log("✅ MongoDB connected successfully"))
.catch(err => {
  console.error("❌ MongoDB connection error:", err);
  console.log("Make sure MongoDB is running on your system.");
});

// User Schema & Model
const userSchema = new mongoose.Schema({
  username: { type: String, required: true, unique: true },
  password: { type: String, required: true }
});
const User = mongoose.model('User', userSchema);
const contactSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true },
  phone: { type: String, required: true },
  subject: { type: String, required: true },
  message: { type: String, required: true },
  date: { type: Date, default: Date.now }
});
const Contact = mongoose.model('Contact', contactSchema); 
// Signup Route
app.post('/signup', async (req, res) => {
  try {
    const { username, password } = req.body;
    if (!username || !password) {
      return res.status(400).json({ message: 'Username and password are required' });
    }

    const existingUser = await User.findOne({ username });
    if (existingUser) return res.status(400).json({ message: 'User already exists' });

    const newUser = new User({ username, password });
    await newUser.save();
    res.status(201).json({ message: 'User created successfully' });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Error creating user' });
  }
});

// Login Route
app.post('/login', async (req, res) => {
  try {
    const { username, password } = req.body;
    if (!username || !password) {
      return res.status(400).json({ message: 'Username and password are required' });
    }

    const user = await User.findOne({ username });
    if (!user) return res.status(400).json({ message: 'User not found' });
    if (user.password !== password) return res.status(400).json({ message: 'Invalid password' });

    res.json({
      message: 'Login successful',
      userId: user._id,
      username: user.username
    });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: 'Login error' });
  }
});

// Product Schema & Model
const productSchema = new mongoose.Schema({
  username: { type: String, required: true },
  productId: { type: String, required: true },
  name: { type: String, required: true },
  price: { type: Number, required: true },
  discountedPrice: { type: Number },
  quantity: { type: Number, default: 1 },
  image: { type: String },
  category: { type: String },
  material: { type: String },
  colors: { type: String },
  unit: { type: String },
  addedDate: { type: Date, default: Date.now }
});
const Product = mongoose.model('Product', productSchema);

// Order Schema & Model
const orderSchema = new mongoose.Schema({
  username: { type: String, required: true },
  products: [{
    productId: { type: String, required: true },
    name: { type: String, required: true },
    price: { type: Number, required: true },
    discountedPrice: { type: Number },
    quantity: { type: Number, default: 1 },
    image: { type: String },
    category: { type: String },
    material: { type: String },
    colors: { type: String },
    unit: { type: String }
  }],
  orderDate: { type: Date, default: Date.now },
  status: { type: String, default: 'successful' }
});
const Order = mongoose.model('Order', orderSchema);

// ✅ Test Endpoint
app.get('/api/test', (req, res) => {
  res.json({ message: 'Server is working', timestamp: new Date() });
});

// ✅ Echo Endpoint
app.post('/api/echo', (req, res) => {
  console.log('Echo received:', req.body);
  res.json({ message: 'Echo received', receivedData: req.body });
});

// ✅ Add product to cart (not real cart, just a DB entry)
app.post('/api/products', async (req, res) => {
  try {
    const { username, product } = req.body;
    if (!username) return res.status(400).json({ message: 'User information required' });
    if (!product) return res.status(400).json({ message: 'Product information required' });

    const newProduct = new Product({
      username,
      productId: product.id?.toString() || 'unknown',
      name: product.name || 'Unknown Product',
      price: product.price || 0,
      discountedPrice: product.discountedPrice,
      quantity: product.quantity || 1,
      image: product.image || '',
      category: product.category || '',
      material: product.material || '',
      colors: product.selectedColor || '',
      unit: product.unit || ''
    });

    await newProduct.save();
    res.status(201).json({ message: 'Product added successfully', productId: newProduct._id });
  } catch (error) {
    console.error('Product add error:', error);
    res.status(500).json({ message: 'Error adding product', error: error.message });
  }
});

// ✅ Get products by user
app.get('/api/products/:username', async (req, res) => {
  try {
    const { username } = req.params;
    if (!username) return res.status(400).json({ message: 'Username is required' });

    const products = await Product.find({ username }).sort({ addedDate: -1 });
    res.json(products);
  } catch (error) {
    console.error('Error fetching products:', error);
    res.status(500).json({ message: 'Error fetching products', error: error.message });
  }
});

// ✅ Place order for all products
app.post('/api/orders', async (req, res) => {
  try {
    const { username, products } = req.body;

    if (!username || !Array.isArray(products) || products.length === 0) {
      return res.status(400).json({ message: 'Username and product list are required' });
    }

    const newOrder = new Order({ username, products });
    await newOrder.save();

    res.status(201).json({ message: 'Order created successfully', orderId: newOrder._id });
    console.log('✅ Order saved to MongoDB:', newOrder);
  } catch (error) {
    console.error('Order error:', error);
    res.status(500).json({ message: 'Error creating order', error: error.message });
  }
});

// ✅ Get all orders
app.get('/api/orders', async (req, res) => {
  try {
    const orders = await Order.find().sort({ orderDate: -1 });
    res.json(orders);
  } catch (error) {
    console.error('Error fetching orders:', error);
    res.status(500).json({ message: 'Error fetching orders' });
  }
});
app.post('/api/contact', async (req, res) => {
  try {
    const { name, email, phone, subject, message } = req.body;

    if (!name || !email || !phone || !subject || !message) {
      return res.status(400).json({ error: 'All fields are required' });
    }

    const newContact = new Contact({ name, email, phone, subject, message });
    await newContact.save();

    res.status(200).json({ message: 'Inquiry submitted successfully!' });
  } catch (err) {
    console.error('Contact form error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// ✅ Start Server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`🚀 Server running on port ${PORT}`);
  console.log(`🔗 Test it at: http://localhost:${PORT}/api/test`);
});
