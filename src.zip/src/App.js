import './App.css';
import './global.css';
import './modern-touches.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.bundle.min';

import React, { useReducer, useEffect, useState, useMemo } from 'react';
import AllRouter from './All_router';
import { cartReducer, calculateCartTotal, calculateCartItemCount } from './CartContext';
import Footer from './footer';

const initialCartState = {
  items: [],
};

function App() {
  const [cartState, dispatch] = useReducer(cartReducer, initialCartState);
  const cartTotal = calculateCartTotal(cartState.items);
  const cartItemCount = calculateCartItemCount(cartState.items);

  // ✅ New cart methods
  const removeFromCart = (productId, selectedColor) => {
    dispatch({ type: 'REMOVE_FROM_CART', payload: { productId, selectedColor } });
  };

  const updateQuantity = (productId, quantity, selectedColor) => {
    dispatch({ type: 'UPDATE_QUANTITY', payload: { productId, quantity, selectedColor } });
  };

  const clearCart = () => {
    dispatch({ type: 'CLEAR_CART' });
  };

  // ✅ Add them to the cart object
  const cart = useMemo(() => ({
    items: cartState.items,
    dispatch,
    cartTotal,
    cartItemCount,
    removeFromCart,
    updateQuantity,
    clearCart,
  }), [cartState.items, cartTotal, cartItemCount]);

  // Auth logic
  const [user, setUser] = useState(() => {
    const storedUser = localStorage.getItem('user');
    return storedUser ? JSON.parse(storedUser) : null;
  });

  const login = (userData) => {
    setUser(userData);
    localStorage.setItem('user', JSON.stringify(userData));
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('user');
  };

  const auth = useMemo(() => ({
    user,
    login,
    logout,
    isAuthenticated: !!user,
  }), [user]);

  return (
    <div className="App">
      <AllRouter auth={auth} cart={cart} />
      <Footer/>
    </div>
  );
}

export default App;
