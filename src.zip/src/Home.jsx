import React from 'react';
import Video from './BGvideo';
import CategoriesCarousel from './categories_carousel';
import { useState } from 'react';
import './Home.css';
import Footer from './footer';


function Home() {
    // import React, { useState } from 'react';


  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    subject: '',
    message: ''
  });

  const handleChange = (e) => {
    setFormData(prev => ({
      ...prev,
      [e.target.id]: e.target.value
    }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();

    try {
      const res = await fetch('http://localhost:5000/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(formData)
      });

      const data = await res.json();

      if (res.ok) {
        alert('Inquiry submitted successfully!');
        setFormData({
          name: '',
          email: '',
          phone: '',
          subject: '',
          message: ''
        });
      } else {
        alert(`Error: ${data.error || 'Something went wrong'}`);
      }
    } catch (err) {
      alert('Server Error');
    }
  };

    return (
        <>
            {/* Hero Section with Video */}
            <Video />
            
            {/* Categories Section */}
            <CategoriesCarousel />
            
            {/* Products Section */}
            
            
           {/* About Us Section */} 
<section id="about" className="about-section">
    <div className="container">
        <div className="section-header">
            <span className="section-subtitle">ECO-FRIENDLY. ELEGANT. ESSENTIAL.</span>
            <h2 className="section-title">Who We Are</h2>
        </div>
        <div className="about-container">
            <div className="about-image">
                <div className="image-overlay"></div>
                <img 
                    src="box_category.webp" 
                    alt="Eco-Friendly Products" 
                />
                <div className="experience-badge">
                    <span className="badge-number">10+</span>
                    <p className="badge-text">Years of Sustainability</p>
                </div>
            </div>
            <div className="about-content">
                <h3>Sustainability Meets Utility</h3>
                <p className="about-description">
                    Since 2010, we’ve been committed to redefining everyday dining with eco-conscious alternatives. 
                    Our journey started with a simple goal: offer elegant, biodegradable cups, glasses, dishes, and containers that protect the planet without compromising quality.
                </p>
                <div className="about-features">
                    <div className="feature">
                        <div className="feature-icon">
                            <svg viewBox="0 0 24 24" width="24" height="24">
                                <path fill="currentColor" d="M9,20.42L2.79,14.21L5.62,11.38L9,14.77L18.88,4.88L21.71,7.71L9,20.42Z" />
                            </svg>
                        </div>
                        <div className="feature-content">
                            <h4>Eco-Friendly Materials</h4>
                            <p>Made from areca palm, sugarcane bagasse, and recycled paper</p>
                        </div>
                    </div>
                    <div className="feature">
                        <div className="feature-icon">
                            <svg viewBox="0 0 24 24" width="24" height="24">
                                <path fill="currentColor" d="M9,20.42L2.79,14.21L5.62,11.38L9,14.77L18.88,4.88L21.71,7.71L9,20.42Z" />
                            </svg>
                        </div>
                        <div className="feature-content">
                            <h4>100% Compostable</h4>
                            <p>Designed to return to nature, not to the landfill</p>
                        </div>
                    </div>
                    <div className="feature">
                        <div className="feature-icon">
                            <svg viewBox="0 0 24 24" width="24" height="24">
                                <path fill="currentColor" d="M9,20.42L2.79,14.21L5.62,11.38L9,14.77L18.88,4.88L21.71,7.71L9,20.42Z" />
                            </svg>
                        </div>
                        <div className="feature-content">
                            <h4>Premium Finish</h4>
                            <p>Elegant design for both personal and professional use</p>
                        </div>
                    </div>
                </div>
                {/* <button className="about-button">
                    {/* <span>Explore Our Products</span> */}
                    {/* <div className="button-arrow">
                        <svg viewBox="0 0 24 24" width="16" height="16">
                            <path fill="currentColor" d="M8.59,16.58L13.17,12L8.59,7.41L10,6L16,12L10,18L8.59,16.58Z" />
                        </svg>
                    </div>
                </button> */} 
            </div>
        </div>
    </div>
</section>

          <section id="transport" className="bulk-section">
  <div className="container">
    <div className="section-header">
      <span className="section-subtitle">RELIABLE LOGISTICS</span>
      <h2 className="section-title">Bulk Order Delivery</h2>
    </div>

    <div className="bulk-grid">
      {/* CARD 1 */}
      <div className="bulk-card">
        <div className="card-icon">
          <svg viewBox="0 0 24 24" width="48" height="48">
            <path fill="var(--primary)" d="M18,18.5A1.5..." />
          </svg>
        </div>
        <h3>Pan-India Delivery</h3>
        <p>Timely transport for high-volume orders anywhere in India</p>
      </div>

      {/* CARD 2 */}
      <div className="bulk-card">
        <div className="card-icon">
          <svg viewBox="0 0 24 24" width="48" height="48">
            <path fill="var(--primary)" d="M12,2A10..." />
          </svg>
        </div>
        <h3>Real-Time Tracking</h3>
        <p>Track your shipment from dispatch to doorstep</p>
      </div>

      {/* CARD 3 */}
      <div className="bulk-card">
        <div className="card-icon">
          <svg viewBox="0 0 24 24" width="48" height="48">
            <path fill="var(--primary)" d="M12,3L2,12H5V..." />
          </svg>
        </div>
        <h3>Bulk Packaging Expertise</h3>
        <p>Secure, weatherproof loading & transportation of disposables</p>
      </div>

      {/* CARD 4 */}
      <div className="bulk-card">
        <div className="card-icon">
          <svg viewBox="0 0 24 24" width="48" height="48">
            <path fill="var(--primary)" d="M12,20A8,8..." />
          </svg>
        </div>
        <h3>Flexible Delivery Slots</h3>
        <p>Custom schedules to match your business needs</p>
      </div>
    </div>

    {/* STATS SECTION (optional placement) */}
    <div className="stats-container" style={{ marginTop: '4rem' }}>
      <div className="stat">
        <div className="stat-number">98%</div>
        <div className="stat-label">Bulk Orders Delivered On-Time</div>
      </div>
      <div className="stat">
        <div className="stat-number">24/7</div>
        <div className="stat-label">Dispatch Support</div>
      </div>
      <div className="stat">
        <div className="stat-number">500+</div>
        <div className="stat-label">Businesses Served Monthly</div>
      </div>
    </div>
  </div>
</section>
        

            
<section id="printing" className="printing-section">
  <div className="container">
    <div className="section-header">
      <span className="section-subtitle">CUSTOMIZATION OPTIONS</span>
      <h2 className="section-title">Printing on Packaging</h2>
    </div>

    <div className="printing-grid">
      <div className="printing-card">
        <div className="printing-card-header">
          <h3>Custom Branding on Disposables</h3>
          <div className="printing-badge">Included Service</div>
        </div>
        <p>
          One_Stop Disposables provides tailored printing services on a wide range of packaging materials, including paper cups, plastic containers, and food boxes. With our advanced printing technology, businesses can elevate their branding directly on every product they serve.
        </p>
        <div className="printing-features">
          <div className="printing-feature">
            <svg viewBox="0 0 24 24" width="20" height="20">
              <path fill="var(--success)" d="M21,7L9,19L3.5,13.5L4.91,12.09L9,16.17L19.59,5.59L21,7Z" />
            </svg>
            <span>Food-safe ink printing on paper and plastic</span>
          </div>
          <div className="printing-feature">
            <svg viewBox="0 0 24 24" width="20" height="20">
              <path fill="var(--success)" d="M21,7L9,19L3.5,13.5L4.91,12.09L9,16.17L19.59,5.59L21,7Z" />
            </svg>
            <span>Eco-friendly ink options</span>
          </div>
          <div className="printing-feature">
            <svg viewBox="0 0 24 24" width="20" height="20">
              <path fill="var(--success)" d="M21,7L9,19L3.5,13.5L4.91,12.09L9,16.17L19.59,5.59L21,7Z" />
            </svg>
            <span>Custom logo and messaging placement</span>
          </div>
        </div>
      </div>

      <div className="printing-card">
        <div className="printing-card-header">
          <h3>Printing for All Substrates</h3>
          <div className="printing-badge">Versatile Capabilities</div>
        </div>
        <p>
          Whether it’s glossy, matte, kraft, or biodegradable materials, our printing solutions adapt to all packaging types. Ideal for restaurants, cafés, caterers, and product-based businesses looking to make a lasting impression through packaging.
        </p>
        <div className="printing-features">
          <div className="printing-feature">
            <svg viewBox="0 0 24 24" width="20" height="20">
              <path fill="var(--success)" d="M21,7L9,19L3.5,13.5L4.91,12.09L9,16.17L19.59,5.59L21,7Z" />
            </svg>
            <span>Printing on plastic containers and lids</span>
          </div>
          <div className="printing-feature">
            <svg viewBox="0 0 24 24" width="20" height="20">
              <path fill="var(--success)" d="M21,7L9,19L3.5,13.5L4.91,12.09L9,16.17L19.59,5.59L21,7Z" />
            </svg>
            <span>Printing on kraft food boxes, wraps & trays</span>
          </div>
          <div className="printing-feature">
            <svg viewBox="0 0 24 24" width="20" height="20">
              <path fill="var(--success)" d="M21,7L9,19L3.5,13.5L4.91,12.09L9,16.17L19.59,5.59L21,7Z" />
            </svg>
            <span>Low-MOQ printing for startups</span>
          </div>
        </div>
      </div>
    </div>
  </div>
</section>
            
 
            
            {/* Contact Section */}
            <section id="contact" className="contact-section">
  <div className="container">
    <div className="contact-container">
      <div className="contact-info">
        <div className="section-header">
          <span className="section-subtitle">GET IN TOUCH</span>
          <h2 className="section-title">Contact One_Stop Disposables</h2>
        </div>
        <p className="contact-description">
          Whether you're looking for custom orders, wholesale pricing, or product information,
          our team is here to help. Expect a reply within 24 business hours.
        </p>

        <div className="contact-methods">
          <div className="contact-method">
            <div className="method-icon">
              <svg viewBox="0 0 24 24" width="32" height="32">
                <path fill="var(--primary)" d="M22 6C22 4.9 21.1 4 20 4H4C2.9 4 2 4.9 2 6V18C2 19.1 2.9 20 4 20H20C21.1 20 22 19.1 22 18V6M20 6L12 11L4 6H20M20 18H4V8L12 13L20 8V18Z" />
              </svg>
            </div>
            <div className="method-content">
              <h4>Email</h4>
              <p>sales@onestopdisposables.com</p>
              <p>support@onestopdisposables.com</p>
            </div>
          </div>

          <div className="contact-method">
            <div className="method-icon">
              <svg viewBox="0 0 24 24" width="32" height="32">
                <path fill="var(--primary)" d="M6.62,10.79C8.06,13.62 10.38,15.94 13.21,17.38L15.41,15.18C15.69,14.9 16.08,14.82 16.43,14.93C17.55,15.3 18.75,15.5 20,15.5A1,1 0 0,1 21,16.5V20A1,1 0 0,1 20,21A17,17 0 0,1 3,4A1,1 0 0,1 4,3H7.5A1,1 0 0,1 8.5,4C8.5,5.25 8.7,6.45 9.07,7.57C9.18,7.92 9.1,8.31 8.82,8.59L6.62,10.79Z" />
              </svg>
            </div>
            <div className="method-content">
              <h4>Phone</h4>
              <p>9825399863</p>
              <p>9845674567</p>
            </div>
          </div>

          <div className="contact-method">
            <div className="method-icon">
              <svg viewBox="0 0 24 24" width="32" height="32">
                <path fill="var(--primary)" d="M12,11.5A2.5,2.5 0 0,1 9.5,9A2.5,2.5 0 0,1 12,6.5A2.5,2.5 0 0,1 14.5,9A2.5,2.5 0 0,1 12,11.5M12,2A7,7 0 0,0 5,9C5,14.25 12,22 12,22C12,22 19,14.25 19,9A7,7 0 0,0 12,2Z" />
              </svg>
            </div>
            <div className="method-content">
              <h4>Head Office</h4>
              <p>123 Eco Plaza, Green City, NY</p>
              <p>Open Mon–Fri: 9AM–6PM</p>
            </div>
          </div>
        </div>
      </div>

      <div className="contact-form-container">
        <form className="contact-form" onSubmit={handleSubmit}>
          <div className="form-group">
            <label htmlFor="name" className="form-label">Full Name</label>
            <input
              type="text"
              id="name"
              className="form-input"
              placeholder="Enter your full name"
              value={formData.name}
              onChange={handleChange}
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="email" className="form-label">Email Address</label>
            <input
              type="email"
              id="email"
              className="form-input"
              placeholder="Enter your email"
              value={formData.email}
              onChange={handleChange}
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="phone" className="form-label">Phone Number</label>
            <input
              type="tel"
              id="phone"
              className="form-input"
              placeholder="Enter your phone number"
              value={formData.phone}
              onChange={handleChange}
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="subject" className="form-label">Subject</label>
            <input
              type="text"
              id="subject"
              className="form-input"
              placeholder="Enter subject"
              value={formData.subject}
              onChange={handleChange}
              required
            />
          </div>

          <div className="form-group">
            <label htmlFor="message" className="form-label">Message</label>
            <textarea
              id="message"
              className="form-textarea"
              placeholder="Enter your message"
              value={formData.message}
              onChange={handleChange}
              required
            />
          </div>

          <button type="submit" className="form-button">
            Submit Inquiry
          </button>
        </form>
      </div>
    </div>
  </div>
</section>
{/* <Footer/> */}

        </>
    );
}

export default Home;