import React from 'react';
import './BGvideo.css';

export default function Video() {
  return (
    <div className="home-container px-0">
      {/* Hero Section - Full width with navbar over it */}
      <div className="hero-section">
        {/* Video Background */}
        <video 
          autoPlay 
          loop 
          muted 
          className="video-background"
        >
          <source src="/new_2.mp4" type="video/mp4" />
          Your browser does not support the video trail_2 che  tag.
        </video>
        
        <div className="hero-overlay"></div>
        <div className="hero-content">
          <h1>Welcome to OneStop Disposables</h1>
          <p>Your premium destination for eco-friendly disposable solutions</p>
          {/* <a href="/shop" className="shop-now-btn">Shop Now</a> */}
        </div>
      </div>

      {/* Rest of the content with padding */}
      <div className="page-content">
        {/* Categories Section */}
      </div>
    </div>
  );
}