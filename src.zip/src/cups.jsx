import React from 'react'; 
import ProductTemplate from './ProductTemplate';

const Cups = ({ auth, cart }) => {
  const addToCart = (product, quantity = 1, options = null, username = null) => {
    const enrichedProduct = {
      ...product,
      quantity,
      addedBy: username,
      options,
    };
    cart.dispatch({ type: 'ADD_TO_CART', payload: enrichedProduct });
  };

  const productsData = {
    products: [
      {
    id: 1,
    name: 'Brown Paper Cups (250ml, 100 Pack)',
    image: './250_brown.jpg',
    price: 12.99,
    rating: 4.5,
    reviews: 44,
    stock: 100,
    material: 'Kraft Paper',
    description: 'Natural brown disposable cups made of eco-friendly kraft paper, ideal for hot beverages.',
    features: ['Eco-Friendly', 'Leak-Proof', 'Food Safe'],
    colors: ['#8D6E63'],
    unit: 'pack',
  },
  {
    id: 2,
    name: 'Brown Paper Cups (350ml, 100 Pack)',
    image: './350_brown.jpg',
    price: 14.99,
    rating: 4.6,
    reviews: 51,
    stock: 120,
    material: 'Kraft Paper',
    description: 'Sturdy brown kraft cups with a smooth inner coating for heat retention.',
    features: ['Durable Build', 'Compostable', 'Suitable for Coffee'],
    colors: ['#795548'],
    unit: 'pack',
  },
  {
    id: 3,
    name: 'Brown Paper Cups (500ml, 100 Pack)',
    image: './500_brown.webp',
    price: 17.99,
    rating: 4.4,
    reviews: 39,
    stock: 90,
    material: 'Kraft Paper',
    description: 'Large brown kraft cups suitable for smoothies, juices, or large coffees.',
    features: ['Large Capacity', 'Eco-Conscious', 'Premium Quality'],
    colors: ['#6D4C41'],
    unit: 'pack',
  },

  // White Paper Cups
  {
    id: 4,
    name: 'White Paper Cups (250ml, 100 Pack)',
    image: './cups.jpg',
    price: 12.49,
    rating: 4.3,
    reviews: 32,
    stock: 140,
    material: 'Bleached Paperboard',
    description: 'Classic white paper cups for tea, coffee, and events.',
    features: ['Simple Design', 'Recyclable', 'Clean Finish'],
    colors: ['#FFFFFF'],
    unit: 'pack',
  },
  {
    id: 5,
    name: 'White Paper Cups (350ml, 100 Pack)',
    image: './350_white.jpg',
    price: 14.49,
    rating: 4.5,
    reviews: 47,
    stock: 110,
    material: 'Food Grade Paper',
    description: 'Medium-sized white cups, great for cafés and catering.',
    features: ['Spill-Resistant', 'Eco-Friendly Ink', 'Disposable'],
    colors: ['#F5F5F5'],
    unit: 'pack',
  },
  {
    id: 6,
    name: 'White Paper Cups (500ml, 100 Pack)',
    image: './500_white.jpg',
    price: 17.49,
    rating: 4.4,
    reviews: 40,
    stock: 95,
    material: 'PE Coated Paper',
    description: 'Large white paper cups for all kinds of hot and cold beverages.',
    features: ['Strong Walls', 'Smooth Surface', 'Perfect for Events'],
    colors: ['#FAFAFA'],
    unit: 'pack',
  },

  // Colorful Paper Cups
  {
    id: 7,
    name: 'Colorful Paper Cups (250ml, 100 Pack)',
    image: 'color_250.jpg',
    price: 13.49,
    rating: 4.6,
    reviews: 58,
    stock: 130,
    material: 'Food Grade Colored Paper',
    description: 'Vibrant disposable cups for parties and kids events.',
    features: ['Multicolor', 'Non-toxic Ink', 'Eye-Catching'],
    colors: ['#FFCDD2', '#FFE082', '#B2EBF2', '#D1C4E9'],
    unit: 'pack',
  },
  {
    id: 8,
    name: 'Colorful Paper Cups (350ml, 100 Pack)',
    image: '350_printed.webp',
    price: 15.99,
    rating: 4.7,
    reviews: 63,
    stock: 100,
    material: 'Printed Paper',
    description: 'Bright and fun medium-size cups, great for birthday parties.',
    features: ['Color Variety', 'Durable', 'Ideal for Cold Drinks'],
    colors: ['#E1BEE7', '#C8E6C9', '#FFECB3'],
    unit: 'pack',
  },
  // {
  //   id: 9,
  //   name: 'Colorful Paper Cups (500ml, 100 Pack)',
  //   image: '',
  //   price: 18.49,
  //   rating: 4.5,
  //   reviews: 55,
  //   stock: 85,
  //   material: 'Colored Kraft Paper',
  //   description: 'Large, colorful cups that stand out at any event.',
  //   features: ['Large Size', 'Bright Designs', 'Food Safe'],
  //   colors: ['#FFAB91', '#CE93D8', '#80DEEA'],
  //   unit: 'pack',
  // },

  // Brown 350ml with Lid
  {
    id: 10,
    name: 'Brown Paper Cups with Lid (350ml, 100 Pack)',
    image: '350_brown_lid.jpg',
    price: 17.99,
    rating: 4.8,
    reviews: 69,
    stock: 105,
    material: 'Kraft Paper + Lid',
    description: 'Brown kraft cups with snug-fitting black lids — ideal for takeaway coffee.',
    features: ['Includes Lids', 'Leak-Proof Seal', 'Barista Quality'],
    colors: ['#8D6E63', '#212121'],
    unit: 'set',
    isBestSeller: true,
    isNew: true,
    freeShipping: true,
  },
    ],
    category: 'cup',
    categoryName: 'cups',
    heroImage: 'cups_category.avif',
    heroTitle: 'Eco & Party Friendly Cups',
    heroDescription: 'Shop a variety of cups from compostable to party-style options.',
    faqs: [
      {
        question: 'Are these cups microwave safe?',
        answer: 'Paper and insulated cups are microwave safe. PLA and plastic cups are not.',
      },
      {
        question: 'Can I buy lids separately?',
        answer: 'Yes, for some models we sell lids separately. Check product options.',
      },
    ],
    categories: [
      { name: 'Plates & Bowls', image: 'dish_7.jpg', path: '/dishes' },
      { name: 'Cutlery Sets', image: 'cocktail_napkins.jpg', path: '/napkins' },
      { name: 'Takeaway Boxes', image: '3_box.jpg', path: '/boxes' },
      // { name: 'Napkins', image: '/images/napkins.jpg', path: '/napkin' },
      // { name: 'Straws & Lids', image: '/images/party.jpg' },
      {name: 'Cups & Glasses', image: 'cups_category.avif', path: '/cups' },
      { name: 'Serving Glasses', image: 'glass_category.jpg', path: '/glasses' },
    ],
    theme: 'light',
    showBulkSection: true,
    enableCompare: true,
    enableColorSwatches: true,
  };

  return (
    <ProductTemplate
      {...productsData}
      auth={auth}
      cart={cart}
      addToCart={addToCart}
    />
  );
};

export default Cups;
