// File: Footer.js

import React from 'react';
import { FaFacebookF, FaInstagram, FaLinkedinIn } from 'react-icons/fa';
import './Footer.css'; // Optional: external styles

const Footer = () => {
  return (
    <footer className="footer">
      <div className="footer-container">

        {/* Branding Section */}
        <div className="footer-brand">
          <h2>OneStop Disposables</h2>
          <p>Your trusted supplier for eco-friendly disposable products.</p>
        </div>

        {/* Navigation Links */}
        <div className="footer-links">
          <h4>Quick Links</h4>
          <ul>
            <li><a href="/">Home</a></li>
            {/* <li><a href="/products">Products</a></li>
            <li><a href="/about">About Us</a></li>
            <li><a href="/contact">Contact</a></li> */}
          </ul>
        </div>

        {/* Contact Info */}
        <div className="footer-contact">
          <h4>Contact Us</h4>
          <p>Email: support@onestopdisposables.com</p>
          <p>Phone: +1 (800) 123-4567</p>
          <p>Location: 123 Greenway Blvd, Suite 100</p>
        </div>

        {/* Social Media */}
        <div className="footer-social">
          <h4>Follow Us</h4>
          <div className="social-icons">
            <a href="#"><FaFacebookF /></a>
            <a href="#"><FaInstagram /></a>
            <a href="#"><FaLinkedinIn /></a>
          </div>
        </div>
      </div>

      {/* Bottom */}
      <div className="footer-bottom">
        <p>© {new Date().getFullYear()} OneStop Disposables. All rights reserved.</p>
      </div>
    </footer>
  );
};

export default Footer;