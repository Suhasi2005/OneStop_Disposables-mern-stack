import React, { useState } from 'react';
import './Template.css';
import { Link } from 'react-router-dom';
import { FaShoppingCart, FaEye } from 'react-icons/fa';
// import { Navigate } from 'react-router-dom';
import { useNavigate } from 'react-router-dom';


const DisposableTemplate = ({
  products = [],
  categoryName,
  heroImage,
  heroTitle,
  heroDescription,
  benefits = [
    { icon: '🌱', text: 'Eco-Friendly' },
    { icon: '💰', text: 'Bulk Discounts' },
    { icon: '🚚', text: 'Fast Delivery' },
    { icon: '🏆', text: 'Premium Quality' }
  ],
  categories = [],
  faqs = [],
  theme,
  showBulkSection,
  addToCart,
  auth, // ✅ new auth prop
}) => {
  const navigate = useNavigate();

  const user = auth?.user;
  const username = user?.username;
  const handleBulkInquiryClick = () => {
    navigate('/');
  };
  return (
    <div className={`disposable-template theme-${theme}`}>
      {/* Hero Section */}
      <div
        className="disposable-hero"
        style={{
          backgroundImage: `linear-gradient(rgba(0,0,0,0.3), rgba(0,0,0,0.3)), url(${heroImage})`,
        }}
      >
        <div className="hero-content">
          <h1>{heroTitle}</h1>
          <p>{heroDescription}</p>
        </div>
      </div>

      {/* Benefits Bar */}
      <div className="benefits-bar">
        {benefits.map((benefit, index) => (
          <div className="benefit-item" key={index}>
            <span className="benefit-icon">{benefit.icon}</span>
            <span>{benefit.text}</span>
          </div>
        ))}
      </div>

      {/* All Products */}
      <section className="product-section">
        <div className="section-header">
          <h2>All Products</h2>
          <p className="section-subtitle">Complete collection of our premium disposables</p>
        </div>
        <div className="product-grid">
          {products.map(product => (
            <DisposableProductCard
              key={product.id}
              product={product}
              theme={theme}
              categoryName={categoryName}
              addToCart={addToCart}
              username={username}
            />
          ))}
        </div>
      </section>

      {/* Best Sellers */}
      {products.some(product => product.isBestSeller) && (
        <section className="product-section">
          <div className="section-header">
            <h2>Best Sellers</h2>
            <p className="section-subtitle">Top quality products loved by our customers</p>
          </div>
          <div className="product-grid">
            {products
              .filter(product => product.isBestSeller)
              .map(product => (
                <DisposableProductCard
                  key={`bestseller-${product.id}`}
                  product={product}
                  theme={theme}
                  categoryName={categoryName}
                  addToCart={addToCart}
                  username={username}
                />
              ))}
          </div>
        </section>
      )}

      {/* New Arrivals */}
      {products.some(product => product.isNew) && (
        <section className="product-section">
          <div className="section-header">
            <h2>New Arrivals</h2>
            <p className="section-subtitle">Latest additions to our collection</p>
          </div>
          <div className="product-grid">
            {products
              .filter(product => product.isNew)
              .map(product => (
                <DisposableProductCard
                  key={`new-${product.id}`}
                  product={product}
                  theme={theme}
                  categoryName={categoryName}
                  addToCart={addToCart}
                  username={username}
                />
              ))}
          </div>
        </section>
      )}

      {/* Categories */}
      {/* <section className="categories-section">
  <div className="section-header">
    <h2>Shop by Category</h2>
    <p className="section-subtitle">Find exactly what you need</p>
  </div> */}

  {/* <div className="category-grid">
    {categories.map((category, index) => (
      <div className="category-card" key={index}>
        <div className="category-image-container">
          <img src={category.image} alt={category.name} />
          <div className="category-overlay"></div>
        </div>
        <h3>{category.name}</h3>
        <Link
          to={`/${categoryName}`} // or `/${category.name.toLowerCase()}`
          state={{ category }}
          className="shop-now-btn"
        >
          Shop Now
        </Link>
      </div>
    ))}
  </div>
</section> */}

      {/* Bulk Section */}
      {showBulkSection && (
        <section className="bulk-section">
          <div className="section-header">
            <h2>Bulk Orders</h2>
            <p className="section-subtitle">Special pricing for large quantities</p>
          </div>
          <div className="bulk-content">
            <div className="bulk-info">
              <h3>Get Better Prices on Bulk Orders</h3>
              <ul>
                <li>✓ Discounts on orders over 100 units</li>
                <li>✓ Free shipping on bulk orders</li>
                <li>✓ Priority customer support</li>
                <li>✓ Custom packaging options</li>
              </ul>
              <button className="bulk-inquiry-btn" onClick={handleBulkInquiryClick}>
      Inquire About Bulk Pricing
    </button>
            </div>
            {/* <div className="bulk-image">
              <img src="/images/bulk-order.jpg" alt="Bulk order" />
            </div> */}
          </div>
        </section>
      )}

      {/* FAQs */}
      {faqs.length > 0 && (
        <section className="faq-section">
          <div className="section-header">
            <h2>Frequently Asked Questions</h2>
            <p className="section-subtitle">Everything you need to know</p>
          </div>
          <div className="faq-grid">
            {faqs.map((faq, index) => (
              <div className="faq-item" key={index}>
                <h3>{faq.question}</h3>
                <p>{faq.answer}</p>
              </div>
            ))}
          </div>
        </section>
      )}

      {/* Newsletter */}
      {/* <section className="newsletter-section">
        <div className="newsletter-content">
          <h2>Stay Updated</h2>
          <p>Get the latest product updates and exclusive offers</p>
          <form className="newsletter-form">
            <input type="email" placeholder="Enter your email" required />
            <button type="submit">Subscribe</button>
          </form>
        </div>
      </section> */}
    </div>
  );
};

// ----------------------
// Product Card Component
// ----------------------

const DisposableProductCard = ({ product, theme, categoryName, addToCart, username }) => {
  const [isAddingToCart, setIsAddingToCart] = useState(false);

  const handleAddToCart = async () => {
    if (!product) {
      console.error('No product found to add to cart');
      alert('Product data is missing.');
      return;
    }
    if (!username) {
      console.error('No username found');
      alert('You must be logged in to add items to cart.');
      console.log(username)
      return;
    }

    setIsAddingToCart(true);
    try {
      addToCart(product, 1, null, username);
      setTimeout(() => setIsAddingToCart(false), 1000);
    } catch (error) {
      console.error('Error adding to cart:', error);
      alert('❌ Failed to add item to cart. Please try again.');
      setIsAddingToCart(false);
    }
  };

  return (
    <div className={`disposable-product-card ${theme}`}>
      <div className="product-image-container">
        <img
          src={product.image || '/images/product-placeholder.jpg'}
          alt={product.name || 'Product image not available'}
          className="product-image"
          onError={(e) => {
            const img = e.target;
            if (!img.src.includes('placeholder.jpg')) {
              img.src = '/images/product-placeholder.jpg';
            }
          }}
        />
        {product.isPopular && <span className="popular-badge">BESTSELLER</span>}
        {product.discount && (
          <span className="discount-badge">-{product.discount}%</span>
        )}
        <div className="product-actions">
          <Link
            to={`/${categoryName}/add`}
            state={{ product, categoryName }}
            className="quick-view-btn"
          >
            <FaEye /> View Details
          </Link>
          <button
            className="cart-symbol-btn"
            onClick={handleAddToCart}
            disabled={isAddingToCart}
            title={isAddingToCart ? 'Adding...' : 'Add to Cart'}
          >
            <FaShoppingCart />
          </button>
        </div>
      </div>
      <div className="product-info">
        <div className="product-header">
          <h3>{product.name}</h3>
          {product.brand && <span className="product-brand">{product.brand}</span>}
        </div>

        <div className="product-meta">
          <span className="material">{product.material}</span>
          {product.colors && (
            <div className="color-options">
              {product.colors.slice(0, 4).map((color, i) => (
                <span
                  key={i}
                  className="color-dot"
                  style={{ backgroundColor: color }}
                  title={color}
                />
              ))}
              {product.colors.length > 4 && (
                <span className="more-colors">+{product.colors.length - 4}</span>
              )}
            </div>
          )}
        </div>

        <div className="price-container">
          <div className="price">
            ₹{product.price.toFixed(2)}
            {product.originalPrice && (
              <span className="original-price">₹{product.originalPrice.toFixed(2)}</span>
            )}
          </div>
          {product.unit && <span className="unit"> / {product.unit}</span>}
        </div>

        <div className="product-footer">
          <Link
            to={`/${categoryName}/add`}
            state={{ product, categoryName }}
            className="shop-now-btn"
          >
            Shop Now
          </Link>
          {product.rating && (
            <div className="rating">
              {Array.from({ length: 5 }).map((_, i) => (
                <span key={i} className={i < product.rating ? 'star filled' : 'star'}>
                  {i < product.rating ? '★' : '☆'}
                </span>
              ))}
              <span>({product.reviews || 0})</span>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default DisposableTemplate;
export { DisposableProductCard };
