import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Navbar from './Navbar';
import Home from './Home';
import Shop from './Shop';
// import Contact from './Contact';
import Dish from './dish';
import AddToCartTemplate from './Cart_template';
import Cart from './Cart';
import Login from './Login';
import Signup from './Signup';
import Cups from './cups';
import Boxes from './boxes';
import Glasses from './glasses';
import NapkinsAndCutlery from './napkins';
function AllRouter({ auth, cart }) {
  return (
    <Router>
      <div className="app">
        {/* ✅ Pass auth and cart to Navbar */}
        <Navbar auth={auth} cart={cart} />
        
        <main>
          <Routes>
            <Route path="/" element={<Home />} />
            <Route path="/shop" element={<Shop />} />
            
            <Route
              path="/shop/add"
              element={<AddToCartTemplate cart={cart} auth={auth} />}
            />
            {/* <Route path="/dish" element={<Dish auth={auth} />} /> */}
            <Route path="/dish" element={<Dish auth={auth} cart={cart} />} />
            <Route path="/cups" element={<Cups auth={auth} cart={cart} />} />
            <Route path="/boxes" element={<Boxes auth={auth} cart={cart} />} />
            <Route path="/glasses" element={<Glasses auth={auth} cart={cart} />} />
            <Route path='/napkins' element={<NapkinsAndCutlery auth={auth} cart={cart}/>}/>
            
            



            
            <Route
              path="/dish/add"
              element={<AddToCartTemplate cart={cart} auth={auth} />}
            />
            <Route
              path="/cups/add"
              element={<AddToCartTemplate cart={cart} auth={auth} />}
            />
            <Route
              path="/boxes/add"
              element={<AddToCartTemplate cart={cart} auth={auth} />}
            />
            <Route
              path="/glasses/add"
              element={<AddToCartTemplate cart={cart} auth={auth} />}
            />
            <Route
              path="/napkins/add"
              element={<AddToCartTemplate cart={cart} auth={auth} />}
            />
            <Route
              path="/cart"
              element={<Cart cart={cart} auth={auth} />}
            />
            <Route
              path="/login"
              element={<Login auth={auth} />}
            />
            <Route
              path="/signup"
              element={<Signup auth={auth} />}
            />
            <Route
              path="/buy-now"
              element={
                <AddToCartTemplate
                  buyNowMode={true}
                  cart={cart}
                  auth={auth}
                />
              }
            />
          </Routes>
        </main>
      </div>
    </Router>
  );
}

export default AllRouter;
