import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  FaTrash,
  FaMinus,
  FaPlus,
  FaShoppingCart,
  FaArrowLeft,
} from 'react-icons/fa';
import './Cart.css';

const Cart = ({ auth, cart }) => {
  const {
    items = [],
    cartTotal = 0,
    cartItemCount = 0,
    removeFromCart = () => {},
    updateQuantity = () => {},
    clearCart = () => {},
  } = cart || {};

  const { user } = auth || {};
  const navigate = useNavigate();
  const [isProcessing, setIsProcessing] = useState(false);

  const handleCheckout = async () => {
    if (!user || !user.username) {
      alert('You must be logged in to place an order.');
      return;
    }

    if (items.length === 0) {
      alert('Your cart is empty.');
      return;
    }

    setIsProcessing(true);

    try {
      const productsToSend = items.map((item) => ({
        productId: item.id?.toString() || 'unknown',
        name: item.name || 'Unnamed',
        price: item.price || 0,
        discountedPrice: item.discountedPrice || undefined,
        quantity: item.quantity || 1,
        image: item.image || '',
        category: item.category || '',
        material: item.material || '',
        colors: item.selectedColor || '',
        unit: item.unit || '',
      }));

      const response = await fetch('http://localhost:5000/api/orders', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          username: user.username,
          products: productsToSend,
        }),
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || 'Failed to place order');
      }

      if (!data.orderId) {
        throw new Error('No order ID returned');
      }

      console.log('✅ Order placed:', data.orderId);
      alert(`Order placed successfully! Order ID: ${data.orderId}`);
      clearCart();
    } catch (error) {
      console.error('❌ Error placing order:', error);
      alert('Failed to place order. Please try again.');
    } finally {
      setIsProcessing(false);
    }
  };

  const handleQuantityChange = (item, newQuantity) => {
    if (newQuantity <= 0) {
      removeFromCart(item.id, item.selectedColor);
    } else {
      updateQuantity(item.id, newQuantity, item.selectedColor);
    }
  };

  if (!items.length) {
    return (
      <div className="cart-empty">
        <div className="cart-empty-content">
          <FaShoppingCart className="cart-empty-icon" />
          <h2>Your Cart is Empty</h2>
          <p>Looks like you haven't added any products to your cart yet.</p>
          <button className="btn btn-primary" onClick={() => navigate('/')}>
            <FaArrowLeft /> Continue Shopping
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="cart-page">
      <div className="container">
        <div className="cart-header">
          <button className="btn btn-secondary back-button" onClick={() => navigate('/')}>
            <FaArrowLeft /> Back to Shop
          </button>
          <h1>Shopping Cart ({cartItemCount} items)</h1>
          <button className="btn btn-outline clear-cart-btn" onClick={clearCart}>
            Clear Cart
          </button>
        </div>

        <div className="cart-content">
          <div className="cart-items">
            {items.map((item, index) => (
              <div key={`${item.id}-${item.selectedColor}-${index}`} className="cart-item">
                <div className="cart-item-image">
                  <img src={item.image} alt={item.name} />
                </div>

                <div className="cart-item-details">
                  <h3>{item.name}</h3>
                  <p className="cart-item-material">Material: {item.material}</p>
                  {item.selectedColor && (
                    <div className="cart-item-color">
                      <span>Color: </span>
                      <div
                        className="color-preview"
                        style={{ backgroundColor: item.selectedColor }}
                      ></div>
                    </div>
                  )}
                  <p className="cart-item-unit">Unit: {item.unit}</p>
                </div>

                <div className="cart-item-price">
                  <div className="price-info">
                    {item.discountedPrice ? (
                      <>
                        <span className="current-price">${item.discountedPrice}</span>
                        <span className="original-price">${item.price}</span>
                      </>
                    ) : (
                      <span className="current-price">${item.price}</span>
                    )}
                  </div>
                </div>

                <div className="cart-item-quantity">
                  <div className="quantity-controls">
                    <button
                      className="quantity-btn"
                      onClick={() => handleQuantityChange(item, item.quantity - 1)}
                      disabled={item.quantity <= 1}
                    >
                      <FaMinus />
                    </button>
                    <span className="quantity-display">{item.quantity}</span>
                    <button
                      className="quantity-btn"
                      onClick={() => handleQuantityChange(item, item.quantity + 1)}
                    >
                      <FaPlus />
                    </button>
                  </div>
                </div>

                <div className="cart-item-total">
                  <span className="item-total">
                    ${((item.discountedPrice || item.price) * item.quantity).toFixed(2)}
                  </span>
                </div>

                <div className="cart-item-actions">
                  <button
                    className="remove-btn"
                    onClick={() => removeFromCart(item.id, item.selectedColor)}
                    title="Remove item"
                  >
                    <FaTrash />
                  </button>
                </div>
              </div>
            ))}
          </div>

          <div className="cart-summary">
            <div className="summary-card">
              <h3>Order Summary</h3>

              <div className="summary-row">
                <span>Subtotal ({cartItemCount} items):</span>
                <span>${cartTotal.toFixed(2)}</span>
              </div>

              <div className="summary-row">
                <span>Shipping:</span>
                <span>Free</span>
              </div>

              <div className="summary-row total">
                <span>Total:</span>
                <span>${cartTotal.toFixed(2)}</span>
              </div>

              <button
                className="checkout-btn"
                onClick={handleCheckout}
                disabled={isProcessing}
              >
                {isProcessing ? 'Placing Order...' : `Checkout ($${cartTotal.toFixed(2)})`}
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Cart;
