// cartUtils.js  

// -------------------- Reducer Logic --------------------

export const cartReducer = (state, action) => {
  switch (action.type) {
    case 'ADD_TO_CART': {
      const existingItem = state.items.find(
        item =>
          item.id === action.payload.id &&
          item.selectedColor === action.payload.selectedColor
      );

      if (existingItem) {
        return {
          ...state,
          items: state.items.map(item =>
            item.id === action.payload.id &&
            item.selectedColor === action.payload.selectedColor
              ? { ...item, quantity: item.quantity + action.payload.quantity }
              : item
          )
        };
      } else {
        return {
          ...state,
          items: [...state.items, action.payload]
        };
      }
    }

    case 'REMOVE_FROM_CART':
      return {
        ...state,
        items: state.items.filter(
          item =>
            !(
              item.id === action.payload.id &&
              item.selectedColor === action.payload.selectedColor
            )
        )
      };

    case 'UPDATE_QUANTITY':
      return {
        ...state,
        items: state.items.map(item =>
          item.id === action.payload.id &&
          item.selectedColor === action.payload.selectedColor
            ? { ...item, quantity: action.payload.quantity }
            : item
        )
      };

    case 'CLEAR_CART':
      return {
        ...state,
        items: []
      };

    case 'SET_CART':
      return {
        ...state,
        items: action.payload
      };

    default:
      return state;
  }
};

// -------------------- Helpers --------------------

export const calculateCartTotal = items =>
  items.reduce((total, item) => {
    const price = item.discountedPrice || item.price;
    return total + price * item.quantity;
  }, 0);

export const calculateCartItemCount = items =>
  items.reduce((count, item) => count + item.quantity, 0);

// -------------------- Order Placement --------------------

export const placeOrder = async (username, cartItems, cartTotal) => {
  try {
    const response = await fetch('http://localhost:5000/api/orders', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({
        username,
        items: cartItems.map(item => ({
          id: item.id,
          name: item.name,
          price: item.price,
          discountedPrice: item.discountedPrice,
          quantity: item.quantity,
          image: item.image,
          selectedColor: item.selectedColor,
          material: item.material,
          unit: item.unit
        })),
        total: cartTotal
      })
    });

    if (!response.ok) {
      const errorData = await response.json();
      throw new Error(errorData.message || 'Failed to place orders');
    }

    const result = await response.json();
    return {
      success: true,
      orderId: result.orderId,
      message: 'Order placed successfully'
    };
  } catch (error) {
    throw new Error(error.message || 'Failed to place order');
  }
};

// -------------------- API Add to Cart --------------------

export const addToCart = async (product, quantity, selectedColor, username) => {
  try {
    const response = await fetch('http://localhost:5000/api/products', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        username,
        product: {
          id: product._id || product.id,
          name: product.name,
          price: product.price,
          discountedPrice: product.discountedPrice,
          quantity,
          selectedColor,
          image: product.image,
          material: product.material,
          category: product.category,
          unit: product.unit
        }
      }),
    });

    const data = await response.json();

    if (!response.ok) {
      throw new Error(data.message || 'Failed to add item to cart');
    }

    console.log('✅ Added to cart:', data);
    return data;
  } catch (error) {
    console.error('❌ Add to cart error:', error);
    throw error;
  }
};
