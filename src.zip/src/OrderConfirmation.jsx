import React from 'react'; 
import { FaCheckCircle, FaTimes } from 'react-icons/fa';
import './OrderConfirmation.css';

const OrderConfirmation = ({ orderDetails, onClose }) => {
  return (
    <div className="order-confirmation-overlay">
      <div className="order-confirmation-modal">
        <button className="close-btn" onClick={onClose}>
          <FaTimes />
        </button>
        
        <div className="confirmation-header">
          <FaCheckCircle className="success-icon" />
          <h2>Order Confirmed!</h2>
          <p>Thank you for your purchase</p>
          <p className="order-id">Order #: {orderDetails.orderId || 'ORD' + Math.random().toString(36).substr(2, 8).toUpperCase()}</p>
        </div>
        
        <div className="order-summary">
          <h3>Order Summary</h3>
          <div className="product-info">
            <div>
              <h4>{orderDetails.name}</h4>
              <p>Quantity: {orderDetails.quantity}</p>
            </div>
          </div>
          
          <div className="price-summary">
            <div className="price-row">
              <span>Subtotal:</span>
              <span>₹{(orderDetails.price * orderDetails.quantity).toFixed(2)}</span>
            </div>
            <div className="price-row">
              <span>Shipping:</span>
              <span>Free</span>
            </div>
            <div className="price-row total">
              <span>Total:</span>
              <span>₹{(orderDetails.price * orderDetails.quantity).toFixed(2)}</span>
            </div>
          </div>
        </div>
        
        <div className="confirmation-footer">
          <p>We've sent a confirmation email with your order details.</p>
          <button className="continue-shopping-btn" onClick={onClose}>
            Continue Shopping
          </button>
        </div>
      </div>
    </div>
  );
};

export default OrderConfirmation;
