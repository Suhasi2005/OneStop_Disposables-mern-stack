// DOM Elements
const productContainer = document.getElementById('product-container');
const filterButtons = document.querySelectorAll('.filter-btn');
const cartCount = document.querySelector('.cart-count');
const cartIcon = document.querySelector('.cart-icon');
const searchInput = document.querySelector('.search-box input');

// Cart array to store added products
let cart = JSON.parse(localStorage.getItem('cart')) || [];

// Initialize the page
document.addEventListener('DOMContentLoaded', () => {
    displayProducts(products);
    updateCartCount();
    
    // Add event listeners
    filterButtons.forEach(button => {
        button.addEventListener('click', filterProducts);
    });
    
    cartIcon.addEventListener('click', () => {
        alert('Cart functionality would be implemented here. Currently you have ' + cart.length + ' items in your cart.');
    });
    
    searchInput.addEventListener('input', searchProducts);
    
    // Add animation classes
    const sections = document.querySelectorAll('section');
    sections.forEach((section, index) => {
        section.classList.add('fade-in', `delay-${index % 3}`);
    });
});

// Display products function
function displayProducts(productsToDisplay) {
    productContainer.innerHTML = '';
    
    if (productsToDisplay.length === 0) {
        productContainer.innerHTML = '<p class="no-products">No products found matching your criteria.</p>';
        return;
    }
    
    productsToDisplay.forEach(product => {
        const productCard = document.createElement('div');
        productCard.className = 'product-card';
        productCard.dataset.category = product.category;
        
        // Create badge if product is eco-friendly
        const badge = product.eco ? `<div class="product-badge eco">Eco-Friendly</div>` : '';
        
        // Create star rating
        const stars = Array(Math.floor(product.rating)).fill('<i class="fas fa-star"></i>').join('');
        const halfStar = product.rating % 1 >= 0.5 ? '<i class="fas fa-star-half-alt"></i>' : '';
        const emptyStars = Array(5 - Math.ceil(product.rating)).fill('<i class="far fa-star"></i>').join('');
        
        productCard.innerHTML = `
            ${badge}
            <div class="product-image">
                <img src="${product.image}" alt="${product.name}">
                <div class="product-actions">
                    <button class="quick-view" data-id="${product.id}"><i class="fas fa-eye"></i></button>
                    <button class="add-to-wishlist" data-id="${product.id}"><i class="fas fa-heart"></i></button>
                </div>
            </div>
            <div class="product-info">
                <p class="product-category">${product.category}</p>
                <h3 class="product-title">${product.name}</h3>
                <div class="product-price">
                    <span class="current-price">$${product.price.toFixed(2)}</span>
                    ${product.originalPrice ? `<span class="original-price">$${product.originalPrice.toFixed(2)}</span>` : ''}
                </div>
                <div class="product-rating">
                    ${stars}${halfStar}${emptyStars}
                    <span>(${product.reviews})</span>
                </div>
                <button class="add-to-cart" data-id="${product.id}">Add to Cart</button>
            </div>
        `;
        
        productContainer.appendChild(productCard);
    });
    
    // Add event listeners to the new buttons
    document.querySelectorAll('.add-to-cart').forEach(button => {
        button.addEventListener('click', addToCart);
    });
    
    document.querySelectorAll('.quick-view').forEach(button => {
        button.addEventListener('click', quickView);
    });
    
    document.querySelectorAll('.add-to-wishlist').forEach(button => {
        button.addEventListener('click', addToWishlist);
    });
}

// Filter products function
function filterProducts(e) {
    const filter = e.target.dataset.filter;
    
    // Update active button
    filterButtons.forEach(button => {
        button.classList.remove('active');
    });
    e.target.classList.add('active');
    
    if (filter === 'all') {
        displayProducts(products);
        return;
    }
    
    const filteredProducts = products.filter(product => {
        if (filter === 'eco') {
            return product.eco;
        }
        return product.category.toLowerCase() === filter;
    });
    
    displayProducts(filteredProducts);
}

// Search products function
function searchProducts() {
    const searchTerm = searchInput.value.toLowerCase();
    
    if (searchTerm === '') {
        // If search is empty, show products based on active filter
        const activeFilter = document.querySelector('.filter-btn.active').dataset.filter;
        if (activeFilter === 'all') {
            displayProducts(products);
        } else {
            filterProducts({ target: document.querySelector(`.filter-btn[data-filter="${activeFilter}"]`) });
        }
        return;
    }
    
    const searchedProducts = products.filter(product => {
        return (
            product.name.toLowerCase().includes(searchTerm) ||
            product.description.toLowerCase().includes(searchTerm) ||
            product.category.toLowerCase().includes(searchTerm)
        );
    });
    
    displayProducts(searchedProducts);
}

// Add to cart function
function addToCart(e) {
    const productId = parseInt(e.target.dataset.id);
    const product = products.find(p => p.id === productId);
    
    // Check if product is already in cart
    const existingItem = cart.find(item => item.id === productId);
    
    if (existingItem) {
        existingItem.quantity += 1;
    } else {
        cart.push({
            ...product,
            quantity: 1
        });
    }
    
    // Update localStorage
    localStorage.setItem('cart', JSON.stringify(cart));
    
    // Update cart count
    updateCartCount();
    
    // Show added notification
    showNotification(`${product.name} added to cart!`);
}

// Update cart count
function updateCartCount() {
    const totalItems = cart.reduce((total, item) => total + item.quantity, 0);
    cartCount.textContent = totalItems;
}

// Quick view function
function quickView(e) {
    const productId = parseInt(e.target.closest('button').dataset.id);
    const product = products.find(p => p.id === productId);
    
    // In a real implementation, this would open a modal with more product details
    alert(`Quick view for ${product.name}\n\n${product.description}\n\nPrice: $${product.price.toFixed(2)}`);
}

// Add to wishlist function
function addToWishlist(e) {
    const productId = parseInt(e.target.closest('button').dataset.id);
    const product = products.find(p => p.id === productId);
    
    // In a real implementation, this would add to a wishlist array
    showNotification(`${product.name} added to wishlist!`);
    e.target.closest('button').innerHTML = '<i class="fas fa-heart" style="color: red;"></i>';
}

// Show notification function
function showNotification(message) {
    const notification = document.createElement('div');
    notification.className = 'notification';
    notification.textContent = message;
    document.body.appendChild(notification);
    
    setTimeout(() => {
        notification.classList.add('show');
    }, 10);
    
    setTimeout(() => {
        notification.classList.remove('show');
        setTimeout(() => {
            document.body.removeChild(notification);
        }, 300);
    }, 3000);
}

// Add notification styles dynamically
const notificationStyles = document.createElement('style');
notificationStyles.textContent = `
    .notification {
        position: fixed;
        bottom: 20px;
        left: 50%;
        transform: translateX(-50%);
        background-color: var(--primary-color);
        color: white;
        padding: 15px 25px;
        border-radius: 5px;
        box-shadow: 0 5px 15px rgba(0, 0, 0, 0.2);
        z-index: 1000;
        opacity: 0;
        transition: opacity 0.3s ease;
    }
    
    .notification.show {
        opacity: 1;
    }
`;
document.head.appendChild(notificationStyles);