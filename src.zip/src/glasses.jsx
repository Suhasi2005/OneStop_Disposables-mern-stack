import React from 'react';
import ProductTemplate from './ProductTemplate';

const Glasses = ({ auth, cart }) => {
  const addToCart = (product, quantity = 1, options = null, username = null) => {
    const enrichedProduct = {
      ...product,
      quantity,
      addedBy: username,
      options,
    };
    cart.dispatch({ type: 'ADD_TO_CART', payload: enrichedProduct });
  };

  const productsData = {
    products: [
      {
        id: 1,
        name: 'Shot Glass (Set of 6)',
        image: 'shot_glass.jpg',
        price: 14.99,
        discountedPrice: 11.99,
        rating: 4.7,
        reviews: 85,
        stock: 60,
        material: 'Glass',
        description: 'Crystal clear shot glasses perfect for parties and events.',
        features: ['Thick base', 'Dishwasher safe', '6 pcs set'],
        colors: ['#F5F5F5', '#E0E0E0'],
        isNew: true,
        isBestSeller: true,
        unit: 'set',
      },
      {
        id: 2,
        name: 'Cocktail Glass (Set of 4)',
        image: 'cocktail_glass.jpg',
        price: 24.99,
        rating: 4.8,
        reviews: 112,
        stock: 40,
        material: 'Glass',
        description: 'Elegant glasses for cocktails, mocktails, and more.',
        features: ['Premium look', 'Sturdy stem', 'Gift-worthy'],
        colors: ['#FFFFFF', '#ECEFF1'],
        isBestSeller: true,
        unit: 'set',
      },
      {
        id: 3,
        name: 'Transparent Glass with Black Lid (500ml)',
        image: 'glass_lid.jpg',
        price: 9.99,
        discountedPrice: 7.99,
        rating: 4.4,
        reviews: 59,
        stock: 100,
        material: 'Borosilicate Glass',
        description: 'Reusable glass container with airtight black lid.',
        features: ['Leak-proof lid', 'Microwave safe', 'Odor-free'],
        colors: ['#000000', '#F5F5F5'],
        isNew: true,
        unit: 'piece',
      },
      {
        id: 4,
        name: 'Glass with transparent Lid',
        image: 'glass_transparentlid.webp',
        price: 4.99,
        rating: 4.1,
        reviews: 37,
        stock: 80,
        material: 'Glass',
        description: 'Compact glass tube used for smoothies, ice creams, or rolled items.',
        features: ['Durable', 'Minimalist design', 'Smooth finish'],
        colors: ['#FAFAFA'],
        unit: 'piece',
      },
      {
        id: 5,
        name: 'Transparent Glass - 300ml',
        image: 'glass_300ml.jpg',
        price: 6.99,
        rating: 4.5,
        reviews: 42,
        stock: 90,
        material: 'Glass',
        description: 'Sleek and sturdy 300ml transparent glass tumbler.',
        features: ['300ml capacity', 'Clear glass', 'Reusable'],
        colors: ['#FFFFFF'],
        unit: 'piece',
      },
      {
        id: 6,
        name: 'Transparent Glass - 250ml',
        image: 'glass_250ml.jpg',
        price: 5.99,
        rating: 4.4,
        reviews: 38,
        stock: 110,
        material: 'Glass',
        description: 'Elegant 250ml transparent drinking glass for daily use.',
        features: ['250ml capacity', 'Clear design', 'Dishwasher safe'],
        colors: ['#FFFFFF'],
        unit: 'piece',
      },
      {
        id: 7,
        name: 'Transparent Glass - 200ml',
        image: 'glass_200ml.jpg',
        price: 4.49,
        rating: 4.3,
        reviews: 24,
        stock: 130,
        material: 'Glass',
        description: 'Compact 200ml glass ideal for juices and kids.',
        features: ['200ml capacity', 'Lightweight', 'Break-resistant'],
        colors: ['#FFFFFF'],
        unit: 'piece',
      },
      {
        id: 8,
        name: 'Transparent Glass - 180ml',
        image: 'glass_180ml.jpg',
        price: 3.99,
        rating: 4.2,
        reviews: 29,
        stock: 140,
        material: 'Glass',
        description: 'Stylish 180ml small-sized transparent glass.',
        features: ['180ml capacity', 'Sleek shape', 'Reusable & durable'],
        colors: ['#FFFFFF'],
        unit: 'piece',
      },
    ],
    category: 'glass',
    categoryName: 'glasses',
    heroImage: 'https://img.freepik.com/free-photo/drinkware-glass-set-realistic-transparent-container_1441-3325.jpg',
    heroTitle: 'Stylish & Functional Glassware',
    heroDescription: 'Discover premium glasses for every occasion — from shots to smoothies.',
    faqs: [
      {
        question: 'Are these glasses microwave-safe?',
        answer: 'Yes, all glasses are made of borosilicate or premium-grade glass and are microwave-safe unless otherwise noted.',
      },
      {
        question: 'Do the glasses come with lids?',
        answer: 'Some variants come with airtight lids. Please check product details for lid availability.',
      },
    ],
    categories: [
      { name: 'Shot Glasses', image: '/images/shotglass.jpg', path: '/glass' },
      { name: 'Cocktail Glasses', image: '/images/cocktail.jpg', path: '/glass' },
      { name: 'Jars & Containers', image: '/images/containers.jpg', path: '/glass' },
      { name: 'Transparent Glasses', image: '/images/transparent.jpg', path: '/glass' },
    ],
    theme: 'light',
    showBulkSection: true,
    enableCompare: true,
    enableColorSwatches: true,
  };

  return (
    <ProductTemplate
      {...productsData}
      auth={auth}
      cart={cart}
      addToCart={addToCart}
    />
  );
};

export default Glasses;
