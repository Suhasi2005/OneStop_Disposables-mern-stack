import React from 'react';
import ProductTemplate from './ProductTemplate';

const Boxes = ({ auth, cart }) => {
  const addToCart = (product, quantity = 1, options = null, username = null) => {
    const enrichedProduct = {
      ...product,
      quantity,
      addedBy: username,
      options,
    };
    cart.dispatch({ type: 'ADD_TO_CART', payload: enrichedProduct });
  };

  const productsData = {
  products: [
    {
      id: 1,
      name: 'Full Transparent Plastic Box (750ml, 50 Pack)',
      image: 'transparent_box.jpg',
      price: 22.99,
      rating: 4.6,
      reviews: 102,
      stock: 100,
      material: 'Clear PET Plastic',
      description: 'Crystal-clear plastic boxes ideal for displaying food, sweets, and dry items.',
      features: ['Microwave Safe', 'Leak-Proof', 'Crystal Clear'],
      colors: ['#FFFFFF', '#E0E0E0'],
      unit: 'pack',
      isBestSeller: true,
      freeShipping: true,
    },
    {
      id: 2,
      name: 'White Plastic Box (1000ml, 50 Pack)',
      image: 'milky_box.jpg',
      price: 19.99,
      rating: 4.4,
      reviews: 87,
      stock: 120,
      material: 'Food-Grade PP Plastic',
      description: 'Sturdy white containers perfect for takeout, meal prep, and deliveries.',
      features: ['Stain Resistant', 'Microwave Friendly', 'Tight Seal'],
      colors: ['#FFFFFF'],
      unit: 'pack',
    },
    {
      id: 3,
      name: 'Bento Box (3 Compartment, 500ml x 3, 25 Pack)',
      image: 'bento_white_box.jpg',
      price: 24.99,
      rating: 4.8,
      reviews: 95,
      stock: 80,
      material: 'Microwave-Safe Plastic',
      description: 'Ideal meal box with three compartments, great for portion control and lunch packs.',
      features: ['Divided Sections', 'Reusable or Disposable', 'Leak-Resistant'],
      colors: ['#FAFAFA', '#E0E0E0'],
      unit: 'set',
      isNew: true,
      freeShipping: true,
    },
    {
      id: 4,
      name: 'Paper Box (Kraft, 750ml, 50 Pack)',
      image: 'round_brown_box.jpg',
      price: 18.99,
      rating: 4.3,
      reviews: 66,
      stock: 110,
      material: 'Kraft Paper',
      description: 'Eco-friendly kraft paper boxes for food, snacks, and dry fruits.',
      features: ['100% Compostable', 'Grease-Resistant', 'Eco Style'],
      colors: ['#A1887F'],
      unit: 'pack',
    },
    {
      id: 5,
      name: 'Paper Box with Transparent Lid (1000ml, 50 Pack)',
      image: 'paper_lid_box.webp',
      price: 21.49,
      rating: 4.7,
      reviews: 77,
      stock: 90,
      material: 'Kraft Base + PET Lid',
      description: 'Eco-friendly kraft box with see-through lid for presentation and freshness.',
      features: ['Compostable Base', 'Crystal Lid', 'Secure Closure'],
      colors: ['#A1887F', '#E0E0E0'],
      unit: 'pack',
      isNew: true,
    },
    {
      id: 6,
      name: 'Transparent Food Container (Square, 500ml, 50 Pack)',
      image: 'plastic_box.webp',
      price: 17.49,
      rating: 4.4,
      reviews: 59,
      stock: 95,
      material: 'Clear PET Plastic',
      description: 'Transparent and airtight containers for food storage and display.',
      features: ['Crystal Clear', 'Stackable', 'Reusable'],
      colors: ['#FFFFFF'],
      unit: 'pack',
    },
    {
      id: 7,
      name: 'Black Box with Transparent Lid (1000ml, 50 Pack)',
      image: '3_box.jpg',
      price: 20.99,
      rating: 4.6,
      reviews: 82,
      stock: 105,
      material: 'Black Base PP + PET Lid',
      description: 'Elegant black base with see-through lid, perfect for upscale food delivery.',
      features: ['Heat Resistant', 'Premium Presentation', 'Microwave Safe'],
      colors: ['#212121', '#E0E0E0'],
      unit: 'pack',
      isBestSeller: true,
    },
  ],
  category: 'box',
  categoryName: 'boxes',
  heroImage: 'https://img.freepik.com/free-photo/eco-friendly-packaging-containers_23-2148879312.jpg',
  heroTitle: 'Stylish & Functional Takeaway Boxes',
  heroDescription: 'Browse a wide range of sustainable and food-safe boxes for delivery, storage, or serving.',
  faqs: [
    {
      question: 'Are these boxes microwave-safe?',
      answer: 'Yes, all plastic and kraft boxes are microwave-safe unless specified otherwise.',
    },
    {
      question: 'Can I order lids separately?',
      answer: 'Most boxes come with lids, but you can request custom lid-only orders via support.',
    },
  ],
  categories: [
    { name: 'Cups & Glasses', image: '/images/cups.jpg', path: '/cup' },
    { name: 'Cutlery Sets', image: '/images/cutlery.jpg', path: '/cutlery' },
    { name: 'Plates & Bowls', image: '/images/plates.jpg', path: '/dish' },
    { name: 'Napkins', image: '/images/napkins.jpg', path: '/napkin' },
    { name: 'Party Supplies', image: '/images/party.jpg', path: '/party' },
  ],
  theme: 'light',
  showBulkSection: true,
  enableCompare: true,
  enableColorSwatches: true,
};

  return (
    <ProductTemplate
      {...productsData}
      auth={auth}
      cart={cart}
      addToCart={addToCart}
    />
  );
};

export default Boxes;
