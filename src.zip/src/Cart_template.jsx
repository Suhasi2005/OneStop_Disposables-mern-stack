// ================= FRONTEND: AddToCartTemplate.jsx =================

import React, { useState } from 'react';
import { useLocation, useNavigate } from 'react-router-dom';
import './Cart_template.css';
import { FaShoppingCart, FaEye } from 'react-icons/fa';
import OrderConfirmation from './OrderConfirmation';

const AddToCartTemplate = ({ auth, cart }) => {
  const location = useLocation();
  const navigate = useNavigate();
  const { addToCart } = cart;
  const { user } = auth;

  const [quantity, setQuantity] = useState(1);
  const [selectedColor, setSelectedColor] = useState(null);
  const [isAddingToCart, setIsAddingToCart] = useState(false);
  const [isPlacingOrder, setIsPlacingOrder] = useState(false);
  const [message, setMessage] = useState('');
  const [showOrderConfirmation, setShowOrderConfirmation] = useState(false);
  const [orderDetails, setOrderDetails] = useState(null);

  const product = location.state?.product;

  const handleAddToCart = async () => {
    if (!product) return alert('Product info missing.');
    if (Array.isArray(product.colors) && product.colors.length > 0 && !selectedColor) {
      return alert('Please select a color.');
    }

    setIsAddingToCart(true);
    setMessage('');

    try {
      addToCart(product, quantity, selectedColor);

      const response = await fetch('http://localhost:5000/api/products', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          username: user?.username || 'guest',
          product: {
            ...product,
            quantity,
            selectedColor,
          },
        }),
      });

      const data = await response.json();
      if (!response.ok) throw new Error(data.message || 'Failed to save cart item.');
      setMessage('✅ Item added to cart successfully!');
    } catch (error) {
      console.error('Error adding to cart:', error);
      setMessage('❌ Failed to add item to cart.');
    } finally {
      setTimeout(() => setMessage(''), 3000);
      setIsAddingToCart(false);
    }
  };

  const handleShopNow = async () => {
    if (!product) return alert('Product info missing.');
    if (!user?.username) return navigate('/login');
    if (Array.isArray(product.colors) && product.colors.length > 0 && !selectedColor) {
      return alert('Please select a color.');
    }

    setIsPlacingOrder(true);
    setMessage('');

    try {
      const response = await fetch('http://localhost:5000/api/orders', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          username: user.username,
          products: [
            {
              productId: product.id?.toString() || 'unknown',
              name: product.name,
              price: product.price,
              discountedPrice: product.discountedPrice,
              quantity,
              image: product.image,
              category: product.category || '',
              material: product.material || '',
              colors: selectedColor || '',
              unit: product.unit || ''
            },
          ],
        }),
      });

      const data = await response.json();
      if (!response.ok) throw new Error(data.message || 'Failed to place order');

      setOrderDetails({
        name: product.name,
        price: product.discountedPrice || product.price,
        quantity,
        selectedColor,
        image: product.image,
      });

      setShowOrderConfirmation(true);
    } catch (error) {
      console.error('Error placing order:', error);
      setMessage('❌ Failed to place order.');
    } finally {
      setTimeout(() => setMessage(''), 3000);
      setIsPlacingOrder(false);
    }
  };

  const handleQuantityChange = (newQty) => {
    if (newQty >= 1) setQuantity(newQty);
  };

  const handleColorSelect = (color) => setSelectedColor(color);

  const closeOrderConfirmation = () => {
    setShowOrderConfirmation(false);
    setOrderDetails(null);
  };

  if (!product) {
    return (
      <div className="error-message">
        <h2>Product Not Found</h2>
        <p>The product you're looking for doesn't exist.</p>
        <button onClick={() => navigate('/')}> <FaEye /> Back to Home </button>
      </div>
    );
  }

  const isColorSelectionRequired = Array.isArray(product.colors) && product.colors.length > 0;

  return (
    <div className="add-to-cart-template">
      <div className="product-display">
        <div className="product-image">
          {/* <img src={product.image} alt={product.name} /> */}
          <img src={`/${product.image}`} alt={product.name} />

        </div>

        <div className="product-details">
          <h1>{product.name}</h1>
          <p>High-quality {product.material} {product.name.toLowerCase()} perfect for your needs.</p>
          <p><strong>Material:</strong> {product.material}</p>
          <p><strong>Unit:</strong> {product.unit}</p>
          {product.colors && (
            <p><strong>Colors:</strong> {Array.isArray(product.colors) ? product.colors.join(', ') : product.colors}</p>
          )}

          <div className="price-section">
            {product.discountedPrice ? (
              <>
                <div className="current-price">₹{product.discountedPrice.toLocaleString('en-IN', {minimumFractionDigits: 2})}</div>
                <div className="original-price">₹{product.price.toLocaleString('en-IN', {minimumFractionDigits: 2})}</div>
              <div className="discount-badge">
                  Save ₹{(product.price - product.discountedPrice).toLocaleString('en-IN', {minimumFractionDigits: 2})}
              </div>
              </>
            ) : (
              <div className="current-price">${product.price}</div>
            )}
            <div className="unit">per {product.unit}</div>
          </div>

          {isColorSelectionRequired && (
            <div className="color-selection">
              <h3>Select Color</h3>
              <div className="color-options">
                {product.colors.map((color, index) => (
                  <div
                    key={index}
                    className={`color-dot ${selectedColor === color ? 'selected' : ''}`}
                    style={{ backgroundColor: color }}
                    onClick={() => handleColorSelect(color)}
                    title={color}
                  ></div>
                ))}
              </div>
              {selectedColor && (
                <p className="selected-color">
                  Selected: <span style={{ color: selectedColor }}>{selectedColor}</span>
                </p>
              )}
            </div>
          )}

          <div className="quantity-selector">
            <label htmlFor="quantity">Quantity:</label>
            <div className="quantity-controls">
              <button onClick={() => handleQuantityChange(quantity - 1)} disabled={quantity <= 1}>-</button>
              <input
                type="number"
                id="quantity"
                value={quantity}
                onChange={(e) => handleQuantityChange(parseInt(e.target.value) || 1)}
                min="1"
              />
              <button onClick={() => handleQuantityChange(quantity + 1)}>+</button>
            </div>
          </div>

          {message && <div className={`message ${message.includes('✅') ? 'success' : 'error'}`}>{message}</div>}

          <div className="action-buttons">
            {/* <button onClick={handleAddToCart} disabled={isAddingToCart || isPlacingOrder}>
              <FaShoppingCart /> {isAddingToCart ? 'Adding...' : 'Add to Cart'}
            </button> */}
            <button className="bg-primary" onClick={handleShopNow} disabled={isAddingToCart || isPlacingOrder}>
              {isPlacingOrder ? 'Placing Order...' : 'Buy Now'}
            </button>
          </div>
        </div>
      </div>

      {showOrderConfirmation && (
        <OrderConfirmation
          orderDetails={orderDetails}
          onClose={closeOrderConfirmation}
        />
      )}
    </div>
  );
};

export default AddToCartTemplate;

// ================= SERVER FILE: already shared is perfect for this client =================
